package co.gabriel.rickyandmorty.presentation.character_list

import android.app.Application
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import co.gabriel.rickyandmorty.R
import co.gabriel.rickyandmorty.data.model.Character
import co.gabriel.rickyandmorty.databinding.CharacterItemBinding
import com.bumptech.glide.Glide

class CharacterRecyclerViewAdapter(private var characters : List<Character> ) :
    RecyclerView.Adapter<CharacterRecyclerViewAdapter.ViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CharacterItemBinding.inflate(LayoutInflater.from(parent.context),parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return characters.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var cantidad = 0
        var valor = 12000
        var resultado : TextView = holder.itemView.findViewById(R.id.tvCantidad)
        val increment : TextView = holder.itemView.findViewById(R.id.btnMas)
        val decrement : TextView = holder.itemView.findViewById(R.id.btnMenos)
        val acum : TextView = holder.itemView.findViewById(R.id.tvValor)
        val character = characters[position]
        holder.name.text = character.name
        increment.setOnClickListener{
            cantidad += 1
            valor *= cantidad
            resultado.text = cantidad.toString()
            acum.text = valor.toString()
            valor = 12000
        }
        decrement.setOnClickListener{
            if(cantidad>0){
                cantidad -= 1
                valor *= cantidad
                resultado.text = cantidad.toString()
                acum.text = valor.toString()
                valor = 12000
            }
            else{
                //Toast.makeText(Application.,"SAPO",Toast.LENGTH_SHORT).show()
            }
        }

        Glide.with(holder.itemView)
            .load(character.image)
            .thumbnail(0.1f)
            .into(holder.image)
    }


    inner class ViewHolder(binding: CharacterItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val image: ImageView = binding.characterImage
        val name : TextView = binding.characterName
    }

    fun updateCharacters(characters: List<Character>){
        this.characters = characters
        notifyDataSetChanged()
    }

}